export class Assignment {
  _id?: string;
  nom!: string;
  note!: Number;
  remark!: string;
  dateDeRendu!: Date;
  rendu!: boolean;
}
