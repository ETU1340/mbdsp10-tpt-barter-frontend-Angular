import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { ObjectService } from '../../shared/services/object.service';
import { ActivatedRoute, Router } from '@angular/router';
import { IObject } from '../../shared/interfaces/other.interface';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-edit-object',
  standalone: true,
  providers: [provideNativeDateAdapter()],
  templateUrl: './edit-object.component.html',
  styleUrls: ['./edit-object.component.css'],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatButtonModule,
    MatSelectModule,
  ],
})
export class EditObjectComponent implements OnInit {
  object: IObject | undefined;
  // Pour les champs de formulaire
  description = '';
  name = '';
  photos: File[] = []; // Fichiers au lieu de base64
  categoryId: number =0;
  categories: { id: number, title: string }[] = []; // Liste des catégories
  showModal = false;

  constructor(
    private objectService: ObjectService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.objectService.getObject(id).subscribe((object) => {
      this.object = object;
      console.log(this.object);
      if (object !== undefined) {
        this.name = object.name;
        this.description = object.description;
        this.categoryId = object.category.id;
        // Initialiser `photos` si nécessaire (vous pouvez laisser vide pour l'édition)
      }
    });

    this.loadCategories();
  }

  handleCategoryChange(event: any) {
    const selectedCategory = this.categories[event.value];
    if (this.object && selectedCategory) {
      this.categoryId = selectedCategory.id;
    }
  }

  handlePhotoUpload(event: any) {
    const files = event.target.files;
    if (files) {
      for (let i = 0; i < files.length; i++) {
        this.photos.push(files[i]); // Ajouter les fichiers directement au tableau `photos`
      }
    }
  }

  loadCategories() {
    this.objectService.getCategories().subscribe((categories) => {
      console.log(categories);
      this.categories = categories;
    });
  }

  toggleModal() {
    this.showModal = !this.showModal;
  }

  handleUpdate() {
    console.log(this.object);
    if (!this.object) return;
    
    // Envoyer l'ID de l'objet et les autres informations à mettre à jour
    this.objectService.updateObject(
      this.object.id,
      this.name,
      this.description,
      this.categoryId,
      parseInt(this.object.owner.id),
      this.photos // Envoyer les fichiers comme dans le service
    ).subscribe((message) => {
      console.log(message);
      this.router.navigate(['/app/object/details/'+this.object?.id]);
    });
  }

  handleDelete() {
    if (this.object) {
      this.objectService.deleteObject(this.object).subscribe((message) => {
        this.object = undefined;
        this.router.navigate(['/app/objects']);
      });
    }
  }
}
