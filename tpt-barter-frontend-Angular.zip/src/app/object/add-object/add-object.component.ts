import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ObjectService } from '../../shared/services/object.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-add-object',
  standalone: true,
  templateUrl: './add-object.component.html',
  styleUrls: ['./add-object.component.css'],
  imports: [
    FormsModule,
    CommonModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatSelectModule,
  ],
})
export class AddObjectComponent implements OnInit {
  name = '';
  description = '';
  photos: File[] = [];
  ownerId: number | undefined;
  categoryId: number | undefined;
  categories: { id: number, title: string }[] = [];

  constructor(
    private objectService: ObjectService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loadCategories();
  }

  handleCategoryChange(event: any) {
    this.categoryId = event.value;
  }

  handleFileInput(event: any) {
    const files = event.target.files;
    if (files) {
      this.photos = Array.from(files);
    }
  }

  loadCategories() {
    this.objectService.getCategories().subscribe((categories) => {
      this.categories = categories;
    });
  }

  handleAddObject() {
    if (!this.name || !this.description || this.categoryId === undefined) return;
    const userObject = JSON.parse(localStorage.getItem('user')!);
    this.ownerId = Number(userObject.id);

    this.objectService.addObject(
      this.name,
      this.description,
      this.categoryId,
      this.ownerId,
      this.photos
    ).subscribe((response: any) => {
      this.router.navigate(['/app/objects']);
    });
  }
}
