import { Component } from '@angular/core';

@Component({
  selector: 'app-auth-popup',
  standalone: true,
  imports: [],
  templateUrl: './auth-popup.component.html',
  styleUrl: './auth-popup.component.css',
})
export class AuthPopupComponent {}
