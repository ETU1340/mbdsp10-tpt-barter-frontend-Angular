import {
  MatDivider,
  MatDividerModule
} from "./chunk-D6SGVKBW.js";
import "./chunk-SWOKGVAF.js";
import "./chunk-MI7IDKF3.js";
import "./chunk-UANYWW5J.js";
import "./chunk-3Q7TKPWY.js";
import "./chunk-SG3BCSKH.js";
import "./chunk-SAVXX6OM.js";
import "./chunk-PQ7O3X3G.js";
import "./chunk-ASLTLD6L.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
