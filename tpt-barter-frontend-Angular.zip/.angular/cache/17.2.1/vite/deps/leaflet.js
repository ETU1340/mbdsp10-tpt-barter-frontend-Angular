import {
  require_leaflet_src
} from "./chunk-V54HQVUX.js";
import "./chunk-ASLTLD6L.js";
export default require_leaflet_src();
//# sourceMappingURL=leaflet.js.map
